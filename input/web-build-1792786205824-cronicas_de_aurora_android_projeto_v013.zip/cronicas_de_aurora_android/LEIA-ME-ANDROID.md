# Crônicas de Aurora — projeto Android (v0.13)

Este projeto envolve a versão HTML mobile em um aplicativo Android usando WebView. Ele mantém os arquivos do jogo dentro do APK, então não precisa de internet para carregar o jogo em si.

## Como gerar o APK
1. Instale Android Studio atualizado com Android SDK Platform 35 e JDK 17.
2. Abra esta pasta (`cronicas_de_aurora_android`) no Android Studio.
3. Aguarde a sincronização do Gradle.
4. Se solicitado, instale as ferramentas/SDKs indicados pelo Android Studio.
5. Selecione **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
6. O APK de teste ficará em `app/build/outputs/apk/debug/app-debug.apk`.

## Notas
- Aplicativo de teste, não assinado para publicação na Play Store.
- Orientação inicial em paisagem para acomodar o jogo.
- O save continua local no armazenamento WebView.
- Este pacote contém o projeto-fonte; o ambiente de criação não possui Android SDK/Gradle instalado para compilar e validar o APK aqui.
