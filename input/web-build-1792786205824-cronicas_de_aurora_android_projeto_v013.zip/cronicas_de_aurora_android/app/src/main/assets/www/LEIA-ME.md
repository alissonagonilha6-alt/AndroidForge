# Crônicas de Aurora — Mobile v0.13

Edição adaptada para celular, executada no navegador (Android/iPhone). Não é um APK nativo.

## Como jogar
1. Extraia o ZIP.
2. Abra `index.html` em um navegador moderno.
3. Toque em **Nova jornada**.
4. Use o direcional na tela para se mover; toque em **Interagir / Conversar** perto de NPCs.
5. Durante as batalhas, toque nos golpes e nos botões de Orbe, Fugir ou Poção.

## Ajustes mobile
- Layout responsivo para telas estreitas e tablets.
- Botões táteis maiores e com resposta visual.
- Comandos de batalha em duas colunas no celular.
- Painéis, sprites e controles adaptados para retrato e paisagem.
- Área segura e suporte a preferência de movimento reduzido.

## Observação
É uma versão HTML de protótipo; o progresso é salvo no armazenamento local do navegador. Não é um aplicativo APK e não inclui instalação pela Play Store.
